<?php
/**
 * Export exception
 */

declare(strict_types=1);

namespace PhpMyAdmin\Exceptions;

use Exception;

/**
 * Export exception
 */
class ExportException extends Exception
{
}
